def search(query,page=1):

    results=[]

    with open("index.txt",encoding="utf-8") as f:

        for line in f:
            url=line.strip()

            score=0

            if query.lower() in url.lower():
                score+=5

            words=query.lower().split()

            for w in words:
                if w in url.lower():
                    score+=1

            if score>0:
                results.append((url,score))

    results.sort(key=lambda x:x[1],reverse=True)

    per_page=20

    start=(page-1)*per_page
    end=start+per_page

    return results[start:end],len(results)