import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import time

visited=set()
MAX_PAGES=50000

def crawl(url,depth=2):

    if url in visited or len(visited)>=MAX_PAGES:
        return

    try:
        r=requests.get(url,timeout=5)
        soup=BeautifulSoup(r.text,"html.parser")

        print("Indexed:",url)

        with open("index.txt","a",encoding="utf-8") as f:
            f.write(url+"\n")

        visited.add(url)

        if depth>0:
            for link in soup.find_all("a"):
                href=link.get("href")

                if href:
                    new=urljoin(url,href)

                    if new.startswith("http"):
                        crawl(new,depth-1)

        time.sleep(0.3)

    except:
        print("Failed:",url)


with open("websites.txt") as f:
    seeds=f.read().splitlines()

for site in seeds:
    crawl(site)