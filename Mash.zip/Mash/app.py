from flask import Flask,render_template,request
from search import search

app=Flask(__name__)

def chatmash_answer(q):
    return "ChatMash thinks about '"+q+"' and suggests exploring multiple sources for deeper understanding."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/search")
def search_page():

    query=request.args.get("q")
    page=int(request.args.get("page",1))

    results,total=search(query,page)

    return render_template("results.html",
                           query=query,
                           results=results,
                           page=page,
                           total=total)

@app.route("/ai")
def ai():
    q=request.args.get("q")

    answer=None

    if q:
        answer=chatmash_answer(q)

    return render_template("ai.html",answer=answer,q=q)

if __name__=="__main__":
    app.run(host="0.0.0.0", port=10000)